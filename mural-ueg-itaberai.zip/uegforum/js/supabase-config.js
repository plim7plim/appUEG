// ============================================================
//  Troque pelos dados do SEU projeto Supabase
//  (Settings > API > Project URL e anon/publishable key)
// ============================================================

const SUPABASE_URL = 'https://SEU-PROJETO.supabase.co';
const SUPABASE_KEY = 'SUA_CHAVE_ANON_AQUI';

const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
