// ============================================================
//  Turmas: professor cria, aluno entra por código
// ============================================================

(async function inicio() {
  const perfil = await exigirLogin();
  if (!perfil) return;

  if (ehProfessor()) {
    document.getElementById('painelProfessor').classList.remove('oculto');
    document.getElementById('subtitulo').textContent =
      'Turmas que você criou. Passe o código para os alunos entrarem.';
  } else {
    document.getElementById('painelAluno').classList.remove('oculto');
    document.getElementById('subtitulo').textContent =
      'Turmas em que você está matriculado.';
  }

  await carregarTurmas();
})();

// ---------- listar ----------
async function carregarTurmas() {
  const alvo = document.getElementById('listaTurmas');

  if (ehProfessor()) {
    const { data, error } = await sb
      .from('turmas')
      .select('id, nome, disciplina, codigo, criado_em, matriculas(count)')
      .eq('professor_id', PERFIL.id)
      .order('criado_em', { ascending: false });

    if (error) {
      alvo.innerHTML = `<div class="vazio">Não foi possível carregar as turmas. ${esc(error.message)}</div>`;
      return;
    }
    if (!data.length) {
      alvo.innerHTML = `<div class="vazio">Nenhuma turma ainda. Crie a primeira ao lado.</div>`;
      return;
    }

    alvo.innerHTML = data.map(t => {
      const qtd = (t.matriculas && t.matriculas[0]) ? t.matriculas[0].count : 0;
      return `
        <a class="turma" href="turma.html?id=${t.id}">
          <h3>${esc(t.nome)}</h3>
          ${t.disciplina ? `<div class="disc">${esc(t.disciplina)}</div>` : ''}
          <div class="meta">
            <span>Código <span class="codigo">${esc(t.codigo)}</span></span>
            <span>${qtd} ${qtd === 1 ? 'aluno' : 'alunos'}</span>
          </div>
        </a>`;
    }).join('');

  } else {
    const { data, error } = await sb
      .from('matriculas')
      .select('criado_em, turmas ( id, nome, disciplina, codigo, professor:profiles(nome) )')
      .eq('aluno_id', PERFIL.id)
      .order('criado_em', { ascending: false });

    if (error) {
      alvo.innerHTML = `<div class="vazio">Não foi possível carregar as turmas. ${esc(error.message)}</div>`;
      return;
    }
    const turmas = data.map(m => m.turmas).filter(Boolean);
    if (!turmas.length) {
      alvo.innerHTML = `<div class="vazio">Você ainda não está em nenhuma turma. Peça o código ao professor e entre ao lado.</div>`;
      return;
    }

    alvo.innerHTML = turmas.map(t => `
      <a class="turma" href="turma.html?id=${t.id}">
        <h3>${esc(t.nome)}</h3>
        ${t.disciplina ? `<div class="disc">${esc(t.disciplina)}</div>` : ''}
        <div class="meta">
          <span>Prof. ${esc(t.professor ? t.professor.nome : '—')}</span>
          <span>Código <span class="codigo">${esc(t.codigo)}</span></span>
        </div>
      </a>`).join('');
  }
}

// ---------- professor cria turma ----------
const formTurma = document.getElementById('formTurma');
if (formTurma) {
  formTurma.onsubmit = async (e) => {
    e.preventDefault();
    esconderAviso('avisoTurma');
    const btn = document.getElementById('btnCriarTurma');
    btn.disabled = true;
    btn.textContent = 'Criando...';

    const nome = document.getElementById('t_nome').value.trim();
    const disciplina = document.getElementById('t_disciplina').value.trim() || null;

    let erroFinal = null;
    for (let tentativa = 0; tentativa < 5; tentativa++) {
      const { error } = await sb.from('turmas').insert({
        nome, disciplina, codigo: gerarCodigo(), professor_id: PERFIL.id
      });
      if (!error) { erroFinal = null; break; }
      erroFinal = error;
      if (error.code !== '23505') break; // 23505 = código repetido, tenta outro
    }

    if (erroFinal) {
      mostrarAviso('avisoTurma', 'Não deu para criar a turma: ' + erroFinal.message);
    } else {
      formTurma.reset();
      mostrarAviso('avisoTurma', 'Turma criada.', true);
      await carregarTurmas();
    }

    btn.disabled = false;
    btn.textContent = 'Criar turma';
  };
}

// ---------- aluno entra por código ----------
const formEntrarTurma = document.getElementById('formEntrarTurma');
if (formEntrarTurma) {
  formEntrarTurma.onsubmit = async (e) => {
    e.preventDefault();
    esconderAviso('avisoEntrar');
    const btn = document.getElementById('btnEntrarTurma');
    btn.disabled = true;
    btn.textContent = 'Entrando...';

    const codigo = document.getElementById('a_codigo').value.trim().toUpperCase();

    const { data: turma } = await sb
      .from('turmas').select('id, nome').eq('codigo', codigo).maybeSingle();

    if (!turma) {
      mostrarAviso('avisoEntrar', 'Nenhuma turma com esse código. Confira com o professor.');
    } else {
      const { error } = await sb.from('matriculas')
        .insert({ turma_id: turma.id, aluno_id: PERFIL.id });

      if (error && error.code === '23505') {
        mostrarAviso('avisoEntrar', 'Você já está nessa turma.');
      } else if (error) {
        mostrarAviso('avisoEntrar', 'Não deu para entrar: ' + error.message);
      } else {
        formEntrarTurma.reset();
        mostrarAviso('avisoEntrar', 'Pronto, você entrou em ' + turma.nome + '.', true);
        await carregarTurmas();
      }
    }

    btn.disabled = false;
    btn.textContent = 'Entrar na turma';
  };
}
